import * as yup from "yup";

export const userRegistrationValidationRule = yup.object({
  name: yup.string().required("Name is required"),
  username: yup.string().required("Username is required"),
  email: yup.string().email().required("Email is required"),
  phone: yup.string().required("Phone is required"),
  website: yup.string().required("Website is required"),
});

export const postValidateRule = yup.object({
  userId: yup
    .number()
    .required("User Id is required")
    .positive("User Id should be a positive number")
    .integer("User Id should be an integer")
    .max(100, "User Id must be less than 100"),
  title: yup
    .string()
    .required("Title is required")
    .min(5, "Title must be 5 characters long"),
  body: yup
    .string()
    .min(10, "Description must be 10 characters long")
    .required("Description is required"),
});

export const signInValidationSchema = yup.object({
  email: yup
    .string()
    .required("Email is required")
    .email("Invalid email format"),
  password: yup
    .string()
    .required("Password is a required field")
    .min(6, "Password must be at least 6 characters"),
});

export const signUpValidationSchema = yup.object({
  name: yup
    .string()
    .required("Name is required")
    .min(5, "Name must be at least 3"),
  email: yup
    .string()
    .required("Email is required")
    .email("Invalid email format"),
  password: yup
    .string()
    .required("Password is a required field")
    .min(6, "Password must be at least 6 characters"),
  confirmPassword: yup
    .string()
    .required("Please confirm your password")
    .oneOf([yup.ref("password")], "Passwords do not match"),
});
