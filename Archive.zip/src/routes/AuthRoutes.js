import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import "../styles/registrationsForm.css";
import SignInForm from "../pages/auth/SignIn";
import SignUpForm from "../pages/auth/SignUp";

const AuthRoutes = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<SignInForm />} />
        <Route path="/sign-up" element={<SignUpForm />} />
      </Routes>
    </BrowserRouter>
  );
};

export default AuthRoutes;
