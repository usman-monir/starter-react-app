import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import DrawerComponent from "../components/Drawer";
import Users from "../pages/users/All";
import Posts from "../pages/posts/All";
import CreateUserForm from "../pages/users/CreateUser";
import CreatePostForm from "../pages/posts/CreatePost";
import UpdateUserForm from "../pages/users/UpdateUser";
import UpdatePostForm from "../pages/posts/UpdatePost";

const ProtectedRoutes = () => {
  return (
    <BrowserRouter>
      <DrawerComponent />
      <Routes>
        <Route path="/users" element={<Users />} />
        <Route path="/posts" element={<Posts />} />
        <Route path="/create-post" element={<CreatePostForm />} />
        <Route path="/create-user" element={<CreateUserForm />} />
        <Route path="/update-user" element={<UpdateUserForm />} />
        <Route path="/update-post" element={<UpdatePostForm />} />
      </Routes>
    </BrowserRouter>
  );
};

export default ProtectedRoutes;
