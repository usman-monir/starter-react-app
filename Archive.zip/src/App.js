import React, { useState, useEffect } from "react";
import AuthRoutes from "./routes/AuthRoutes";
import ProtectedRoutes from "./routes/ProtectedRoutes";
import { onAuthStateChanged } from "firebase/auth";
import { auth } from "./firebase/config";

const App = () => {
  const [currentUser, setCurrentUser] = useState({});
  const [isLoggedIn, setLoggedIn] = useState(false);

  useEffect(() => {
    onAuthStateChanged(auth, (user) => {
      if (user) {
        setLoggedIn(true);
        setCurrentUser(user);
        console.log(currentUser);
      } else setLoggedIn(false);
    });
  }, [auth]);

  return isLoggedIn ? <ProtectedRoutes /> : <AuthRoutes />;
};
export default App;
