import React from "react";
import FormikForm from "./form";
import FormWithHooks from "./formWithHooks";
import Post from "./Post";
import DrawerComponent from "./Drawer";
import Box from "@mui/material/Box";

const Header = () => {
  return (
    <>
      <DrawerComponent />
      <Box sx={{ width: "80%", marginLeft: "10%" }}>
        <Post />
        <FormikForm />
        <FormWithHooks />
      </Box>
    </>
  );
};

export default Header;
