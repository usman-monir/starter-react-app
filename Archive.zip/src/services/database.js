import { collection, addDoc, getDocs } from "firebase/firestore";
import { db } from "../../firebase/config";

const getAllPosts = async () => {
  const posts = [];
  const querySnapshot = await getDocs(collection(db, "posts"));
  querySnapshot.forEach((doc) => posts.push(doc.data()));
  return posts;
};

const getAllURecords = async (name) => {
  const data = [];
  const querySnapshot = await getDocs(collection(db, name));
  querySnapshot.forEach((doc) => data.push(doc.data()));
  return data;
};
