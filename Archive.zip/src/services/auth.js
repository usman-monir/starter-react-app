import { updateProfile, createUserWithEmailAndPassword } from "firebase/auth";
import { auth } from "../firebase/config";

export const registerUser = (values) =>
  createUserWithEmailAndPassword(auth, values.email, values.password)
    .then((user) => {
      updateProfile(user, { displayName: values.name });
      return { isError: false, user };
    })
    .catch((err) => ({
      isError: true,
      message: "Registration failed",
      error: err.message,
    }));
