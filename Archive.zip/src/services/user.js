import axios from "axios";

export const createUser = (user) =>
  axios.post("http://localhost:3002/users", { ...user });

export const getUsers = () => axios.get("http://localhost:3002/users");

export const updateUserInDB = (state) =>
  axios.put(`http://localhost:3002/users/${state.id}`, state);

export const deleteUserInDB = (id) =>
  axios.delete(`http://localhost:3002/users/${id}`);

export const deleteSelectedUsersInDB = (ids) =>
  ids.map((id) => axios.delete(`http://localhost:3002/users/${id}`));
