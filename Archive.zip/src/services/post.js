import axios from "axios";

export const createPost = (post) =>
  axios.post("http://localhost:3002/posts", { ...post });

export const getPosts = () => axios.get("http://localhost:3002/posts");

export const updatePostInDB = (state) =>
  axios.put(`http://localhost:3002/posts/${state.id}`, state);

export const deletePostInDB = (id) =>
  axios.delete(`http://localhost:3002/posts/${id}`);

export const deleteSelectedPostsInDB = (ids) =>
  ids.map((id) => axios.delete(`http://localhost:3002/posts/${id}`));
