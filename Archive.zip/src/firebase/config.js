import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyCE199wjWcApbS4jDunDO4-lH1TwX7Rp1c",
  authDomain: "getting-started-15b6d.firebaseapp.com",
  projectId: "getting-started-15b6d",
  storageBucket: "getting-started-15b6d.appspot.com",
  messagingSenderId: "296542936235",
  appId: "1:296542936235:web:4a2ba77ded29486edfebee",
  measurementId: "G-H0NBSB5FB1",
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
