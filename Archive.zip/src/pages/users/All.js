import * as React from "react";
import { useState, useEffect } from "react";
import { DataGrid } from "@mui/x-data-grid";
import { Typography } from "@mui/material";
import Button from "@mui/material/Button";
import { useLocation, useNavigate } from "react-router-dom";
import { getUsers } from "../../services/user";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import {
  updateUserInDB,
  deleteUserInDB,
  deleteSelectedUsersInDB,
} from "../../services/user";
import Swal from "sweetalert2";
import { collection, addDoc, getDocs } from "firebase/firestore";
import { db } from "../../firebase/config";

const Users = () => {
  const navigate = useNavigate();
  const [users, setUsers] = useState([]);
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [canDelete, setCanDelete] = useState(false);
  const getData = async () => {
    const users = [];
    const querySnapshot = await getDocs(collection(db, "users"));
    querySnapshot.forEach((doc) => {
      users.push(doc.data());
    });
    setUsers(users);
  };

  const { state } = useLocation();
  const updateUsers = (users) => {
    if (state) {
      const updatedList = users.map((user) =>
        user.id === state.id ? state : user
      );
      setUsers(updatedList);
      updateUserInDB(state);
    }
  };

  useEffect(() => {
    try {
      getData();
    } catch (err) {
      alert(err.message);
    }
  }, []);

  const removeUsers = () => {
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      if (result.isConfirmed) {
        Swal.fire("Deleted!", "Your file has been deleted.", "success");
        const newUsers = users.filter(
          (user) => !selectedUsers.includes(user.id)
        );
        setUsers(newUsers);
        deleteSelectedUsersInDB(selectedUsers);
      }
    });
  };

  const columns = [
    { field: "id", headerName: "ID", width: 70 },
    { field: "name", headerName: "Name", width: 150 },
    { field: "username", headerName: "Username", width: 150 },
    { field: "email", headerName: "Email", width: 150 },
    { field: "phone", headerName: "phone", width: 100 },
    { field: "website", headerName: "website", width: 100 },
    {
      field: "edit",
      headerName: "Edit",
      width: 70,
      sortable: false,
      renderCell: (params) => {
        const onClick = (e) => {
          e.stopPropagation();
          navigate("/update-user", {
            state: params.row,
          });
        };
        return <EditIcon color="success" onClick={onClick} />;
      },
    },
    {
      field: "delete",
      headerName: "Delete",
      width: 70,
      sortable: false,
      renderCell: (params) => {
        const onClick = (e) => {
          e.stopPropagation();
          Swal.fire({
            title: "Are you sure?",
            text: "You won't be able to revert this!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, delete it!",
          }).then((result) => {
            if (result.isConfirmed) {
              Swal.fire("Deleted!", "Your file has been deleted.", "success");
              setUsers(users.filter((user) => user.id !== params.row.id));
              deleteUserInDB(params.row.id);
            }
          });
        };
        return <DeleteIcon sx={{ color: "red" }} onClick={onClick} />;
      },
    },
  ];

  return (
    <div>
      <div>
        <Typography sx={{ textAlign: "center", m: 5 }} variant="h3">
          Users
        </Typography>
        <div style={{ height: 400, width: "95%", margin: "1.5rem" }}>
          <DataGrid
            rows={users}
            columns={columns}
            pageSize={5}
            rowsPerPageOptions={[5]}
            checkboxSelection
            onSelectionModelChange={(ids) => {
              setSelectedUsers(ids);
              if (ids.length > 0) {
                setCanDelete(true);
              } else {
                setCanDelete(false);
              }
            }}
          />
        </div>
        <Button
          sx={{ margin: "1.5rem" }}
          variant="contained"
          color="error"
          disabled={!canDelete}
          onClick={() => removeUsers()}
        >
          Remove
        </Button>
      </div>
    </div>
  );
};

export default Users;
