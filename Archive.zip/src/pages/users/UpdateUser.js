import React from "react";
import { useFormik } from "formik";
import { userRegistrationValidationRule } from "../../utils/validations";
import { useLocation, useNavigate } from "react-router-dom";

const UpdateUserForm = () => {
  const navigate = useNavigate();
  const { state } = useLocation();
  const formik = useFormik({
    enableReinitialize: true,
    initialValues: {
      name: state.name,
      username: state.username,
      phone: state.phone,
      email: state.email,
      website: state.website,
    },
    validationSchema: userRegistrationValidationRule,
    onSubmit: async (user) => {
      navigate("/users", { state: { id: state.id, ...user } });
    },
  });
  return (
    <div className="container p-4">
      <form onSubmit={formik.handleSubmit}>
        <h4>Update User</h4>
        <hr />
        <div className="form-group">
          <label htmlFor="name">Name</label>
          <input
            className="form-control"
            id="name"
            name="name"
            type="text"
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            value={formik.values.name}
          />
          {formik.touched.name && formik.errors.name ? (
            <div>{formik.errors.name}</div>
          ) : null}
        </div>
        <div className="form-group">
          <label htmlFor="username">Username</label>
          <input
            className="form-control"
            id="username"
            name="username"
            type="text"
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            value={formik.values.username}
          />
          {formik.touched.username && formik.errors.username ? (
            <div>{formik.errors.username}</div>
          ) : null}
        </div>

        <div className="form-group">
          <label htmlFor="email">Email</label>
          <input
            className="form-control"
            id="email"
            name="email"
            type="text"
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            value={formik.values.email}
          />
          {formik.touched.email && formik.errors.email ? (
            <div>{formik.errors.email}</div>
          ) : null}
        </div>

        <div className="form-group">
          <label htmlFor="phone">Phone</label>
          <input
            className="form-control"
            id="phone"
            name="phone"
            type="text"
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            value={formik.values.phone}
          />
          {formik.touched.phone && formik.errors.phone ? (
            <div>{formik.errors.phone}</div>
          ) : null}
        </div>

        <div className="form-group">
          <label htmlFor="website">website</label>
          <input
            className="form-control"
            id="website"
            name="website"
            type="text"
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            value={formik.values.website}
          />
          {formik.touched.website && formik.errors.website ? (
            <div>{formik.errors.website}</div>
          ) : null}
        </div>

        <button className="btn btn-primary" type="submit">
          Done
        </button>
      </form>
    </div>
  );
};

export default UpdateUserForm;
