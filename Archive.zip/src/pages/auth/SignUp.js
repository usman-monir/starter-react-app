import { Formik } from "formik";
import React from "react";
import { signUpValidationSchema } from "../../utils/validations";
import { Link } from "react-router-dom";
// import { auth } from "../../firebase/config";
// import { createUserWithEmailAndPassword } from "firebase/auth";
import { useNavigate } from "react-router-dom";
import { SIGNUP_DEFAULT_VALUES } from "../../utils/defaultValues";
import { registerUser } from "../../services/auth";
import Swal from "sweetalert2";

const SignUpForm = () => {
  const navigate = useNavigate();

  const onSubmit = (values) => {
    registerUser(values)
      .then((result) => {
        if (result.isError) {
          // Failure case
          handleFailure();
          // Swal.fire('error', result );
        } else {
          // Success case
          navigate("/");
        }
      })
      .catch((err) => {
        handleFailure();
        // Failure case
        // Swal.fire('error', result );
      });
    // createUserWithEmailAndPassword(auth, values.email, values.password)
    //   .then((res) => {
    //     alert(res.user.email + " added successfully!!");
    //     navigate("/");
    //     auth.currentUser
    //   })
    //   .catch((err) => alert(err.message));
  };

  const handleFailure = (err) => {};

  return (
    <>
      <Formik
        validationSchema={signUpValidationSchema}
        initialValues={SIGNUP_DEFAULT_VALUES}
        onSubmit={onSubmit}
      >
        {({
          values,
          errors,
          touched,
          handleChange,
          handleBlur,
          handleSubmit,
        }) => (
          <div className="body">
            <div className="login">
              <div className="form">
                <form noValidate onSubmit={handleSubmit}>
                  <span>Sign Up</span>

                  <input
                    type="name"
                    name="name"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.name}
                    placeholder="Enter name"
                    className="form-control inp_text"
                    id="name"
                  />

                  <p className="error">
                    {errors.name && touched.name && errors.name}
                  </p>

                  <input
                    type="email"
                    name="email"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.email}
                    placeholder="Enter email id"
                    className="form-control inp_text"
                    id="email"
                  />

                  <p className="error">
                    {errors.email && touched.email && errors.email}
                  </p>

                  <input
                    type="password"
                    name="password"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.password}
                    placeholder="Enter password"
                    className="form-control"
                  />

                  <p className="error">
                    {errors.password && touched.password && errors.password}
                  </p>

                  <input
                    type="password"
                    name="confirmPassword"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.confirmPassword}
                    placeholder="confirm your password"
                    className="form-control"
                  />
                  <p className="error">
                    {errors.confirmPassword &&
                      touched.confirmPassword &&
                      errors.confirmPassword}
                  </p>

                  <button type="submit">Sign Up</button>
                  <div className="link">
                    <Link to={"/"}>SIGN IN</Link>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )}
      </Formik>
    </>
  );
};

export default SignUpForm;
