import { Formik } from "formik";
import React from "react";
import { signInValidationSchema } from "../../utils/validations";
import { Link, useNavigate } from "react-router-dom";
import { auth } from "../../firebase/config";
import { signInWithEmailAndPassword } from "firebase/auth";

const SignInForm = () => {
  const navigate = useNavigate();
  return (
    <>
      <Formik
        validationSchema={signInValidationSchema}
        initialValues={{ email: "", password: "" }}
        onSubmit={async (values) => {
          await signInWithEmailAndPassword(auth, values.email, values.password)
            .then((res) => {
              alert(res.user.email + " has been signed in successfully");
              navigate("/");
            })
            .catch((err) => {
              alert(err.message);
            });
        }}
      >
        {({
          values,
          errors,
          touched,
          handleChange,
          handleBlur,
          handleSubmit,
        }) => (
          <div className="body">
            <div className="login">
              <div className="form">
                <form onSubmit={handleSubmit}>
                  <span>Sign In</span>
                  <input
                    type="email"
                    name="email"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.email}
                    placeholder="Enter email"
                    className="form-control inp_text"
                    id="email"
                  />

                  <p className="error">
                    {errors.email && touched.email && errors.email}
                  </p>

                  <input
                    type="password"
                    name="password"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.password}
                    placeholder="Enter password"
                    className="form-control"
                  />

                  <p className="error">
                    {errors.password && touched.password && errors.password}
                  </p>

                  <button type="submit">Sign In</button>
                  <div className="link">
                    <Link to={"/sign-up"}>SIGN UP</Link>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )}
      </Formik>
    </>
  );
};

export default SignInForm;
