import * as React from "react";
import { useState, useEffect } from "react";
import { DataGrid } from "@mui/x-data-grid";
import { Typography } from "@mui/material";
import Button from "@mui/material/Button";
import { useNavigate, useLocation } from "react-router-dom";
import { getPosts } from "../../services/post";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import {
  updatePostInDB,
  deletePostInDB,
  deleteSelectedPostsInDB,
} from "../../services/post";
import Swal from "sweetalert2";
import { getAllRecords } from "../../services/database";

const Posts = () => {
  const navigate = useNavigate();
  const [posts, setPosts] = useState([]);
  const [selectedPosts, setSelectedPosts] = useState([]);
  const [canDelete, setCanDelete] = useState(false);

  useEffect(() => {
    try {
      setPosts(await getAllRecords("posts"))
    } catch (err) {
      alert(err.message);
    }
    getPosts()
      .then((res) => {
        // res.data.forEach((record) => addDoc(collection(db, "posts"), record));
        // setPosts(res.data);
        updatePosts(res.data);
      })
      .catch((err) => alert(err.message));
  }, []);

  const { state } = useLocation();
  const updatePosts = (posts) => {
    if (state) {
      const updatedList = posts.map((post) =>
        post.id === state.id ? state : post
      );
      setPosts(updatedList);
      updatePostInDB(state);
    }
  };

  const RemovePosts = () => {
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      if (result.isConfirmed) {
        Swal.fire("Deleted!", "Your file has been deleted.", "success");
        const newPosts = posts.filter(
          (post) => !selectedPosts.includes(post.id)
        );
        setPosts(newPosts);
        deleteSelectedPostsInDB(selectedPosts);
      }
    });
  };

  const columns = [
    { field: "userId", headerName: "user id", width: 70 },
    { field: "id", headerName: "Id", width: 70 },
    { field: "title", headerName: "Title", width: 190 },
    { field: "body", headerName: "Description", width: 300 },
    {
      field: "edit",
      headerName: "Edit",
      width: 100,
      sortable: false,
      renderCell: (params) => {
        const onClick = (e) => {
          e.stopPropagation();
          navigate("/update-post", {
            state: params.row,
          });
        };
        return <EditIcon color="success" onClick={onClick} />;
      },
    },
    {
      field: "delete",
      headerName: "Delete",
      width: 100,
      sortable: false,
      renderCell: (params) => {
        const onClick = (e) => {
          e.stopPropagation();
          Swal.fire({
            title: "Are you sure?",
            text: "You won't be able to revert this!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, delete it!",
          }).then((result) => {
            if (result.isConfirmed) {
              Swal.fire("Deleted!", "Your file has been deleted.", "success");
              setPosts(posts.filter((post) => post.id !== params.row.id));
              deletePostInDB(params.row.id);
            }
          });
        };
        return <DeleteIcon sx={{ color: "red" }} onClick={onClick} />;
      },
    },
  ];

  return (
    <div>
      <Typography sx={{ textAlign: "center", m: 5 }} variant="h3">
        Posts
      </Typography>
      <div style={{ height: 400, width: "95%", margin: "1.5rem" }}>
        <DataGrid
          rows={posts}
          columns={columns}
          pageSize={5}
          rowsPerPageOptions={[5]}
          checkboxSelection
          onSelectionModelChange={(ids) => {
            setSelectedPosts(ids);
            if (ids.length > 0) {
              setCanDelete(true);
            } else {
              setCanDelete(false);
            }
          }}
        />
      </div>
      <Button
        sx={{ margin: "1.5rem" }}
        variant="contained"
        color="error"
        disabled={!canDelete}
        onClick={() => RemovePosts()}
      >
        Remove
      </Button>
    </div>
  );
};

export default Posts;
