import React from "react";
import { useFormik } from "formik";
import { postValidateRule } from "../../utils/validations";
import { createPost } from "../../services/post";
import { useNavigate } from "react-router-dom";
import { v4 as uuid } from "uuid";
import { auth } from "../../firebase/config";

const PostForm = () => {
  const unique_id = uuid();
  const small_id = unique_id.slice(0, 8);
  const navigate = useNavigate();
  const formik = useFormik({
    initialValues: {
      userId: auth.currentUser.uid,
      id: small_id,
      title: "",
      body: "",
    },
    validationSchema: postValidateRule,
    onSubmit: (values) => {
      createPost(values)
        .then((res) => navigate("/posts", { state: res.data }))
        .catch((err) => alert(err.message));
    },
  });
  return (
    <div className="container p-4">
      <form onSubmit={formik.handleSubmit}>
        <h4>Create a Post</h4>
        <div className="form-group">
          <label htmlFor="userId">User Id</label>
          <input
            className="form-control"
            id="userId"
            name="userId"
            type="number"
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            value={formik.values.name}
          />
          {formik.touched.userId && formik.errors.userId ? (
            <div>{formik.errors.userId}</div>
          ) : null}
        </div>
        <div className="form-group">
          <label htmlFor="title">Title</label>
          <input
            className="form-control"
            id="title"
            name="title"
            type="text"
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            value={formik.values.title}
          />
          {formik.touched.title && formik.errors.title ? (
            <div>{formik.errors.title}</div>
          ) : null}
        </div>
        <div className="form-group">
          <label htmlFor="body">Description</label>
          <input
            className="form-control"
            id="body"
            name="body"
            type="text"
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            value={formik.values.body}
          />
          {formik.touched.body && formik.errors.body ? (
            <div>{formik.errors.body}</div>
          ) : null}
        </div>

        <button className="btn btn-primary" type="submit">
          Submit
        </button>
      </form>
    </div>
  );
};

export default PostForm;
