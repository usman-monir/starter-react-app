import React from "react";
import { useFormik } from "formik";
import { postValidateRule } from "../../utils/validations";
import { useNavigate, useLocation } from "react-router-dom";

const UpdatePostForm = () => {
  const navigate = useNavigate();
  const { state } = useLocation();
  const formik = useFormik({
    enableReinitialize: true,
    initialValues: {
      userId: state.userId,
      id: state.id,
      title: state.title,
      body: state.body,
    },
    validationSchema: postValidateRule,
    onSubmit: async (post) => {
      navigate("/posts", { state: { id: state.id, ...post } });
    },
  });
  return (
    <div className="container p-4">
      <form onSubmit={formik.handleSubmit}>
        <h4>Update the Post</h4>
        <div className="form-group">
          <label htmlFor="userId">User Id</label>
          <input
            className="form-control"
            id="userId"
            name="userId"
            type="number"
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            value={formik.values.userId}
          />
          {formik.touched.userId && formik.errors.userId ? (
            <div>{formik.errors.userId}</div>
          ) : null}
        </div>
        <div className="form-group">
          <label htmlFor="title">Title</label>
          <input
            className="form-control"
            id="title"
            name="title"
            type="text"
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            value={formik.values.title}
          />
          {formik.touched.title && formik.errors.title ? (
            <div>{formik.errors.title}</div>
          ) : null}
        </div>
        <div className="form-group">
          <label htmlFor="body">Description</label>
          <input
            className="form-control"
            id="body"
            name="body"
            type="text"
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            value={formik.values.body}
          />
          {formik.touched.body && formik.errors.body ? (
            <div>{formik.errors.body}</div>
          ) : null}
        </div>

        <button className="btn btn-primary" type="submit">
          Done
        </button>
      </form>
    </div>
  );
};

export default UpdatePostForm;
